#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
Created on 2019年12月3日
@author: Irony
@site: https://pyqt.site https://github.com/892768447
@email: 892768447@qq.com
@file: 
@description: 
"""


__Author__ = 'Irony'
__Copyright__ = 'Copyright (c) 2019'
__Version__ = 1.0

import PyQt5
from distutils.core import setup
import glob
import os
import py2exe  # @UnusedImport
import sys


sys.argv.append('py2exe')  # 允许程序通过双击的形式执行

# 生成qt.conf
# Plugins=lib/plugins 注意这个，因为放到子文件夹里去了
open('qt.conf', 'wb').write("""[Paths]
Prefix=.
Binaries=.
Plugins=lib/plugins
""".encode())

# 需要什么包这里就加入什么包
includes = [
    'sip',
    'PyQt5.sip',        # 兼容新版的PyQt5
    'PyQt5.QtCore',
    'PyQt5.QtWidgets',
    'PyQt5.QtGui'
]

# 需要排除的包
# 比如你可以只打包一个启动脚本，然后自己的报名排除掉，加入到includes里面，这样会打包到library.zip中，可实现自动升级更新等操作
excludes = []

qtpath = os.path.dirname(PyQt5.__file__)

dll_excludes = ['MSVCP90.dll', 'MSVCR90.dll',
                'MSVCP100.dll', 'MSVCR100.dll', 'w9xpopen.exe']

# compressed 为1 则压缩文件
# optimize 为优化级别 默认为0
options = {
    'py2exe': {
        'skip_archive': False,  # 不要将Python字节码文件放在存档中，直接将它们放在文件系统中
        'unbuffered': True,  # 使用无缓冲的stdout和stderr
        'compressed': 1,
        'optimize': 2,
        'bundle_files': 3,
        'includes': includes,
        'excludes': excludes,
        'dll_excludes': dll_excludes
    }
}

setup(
    version='1.0',
    description='main',
    name='main',
    zipfile='lib/library.zip',          # 注意这里，如果加了目录则会把很多pyd dll等文件放到lib文件夹
    options=options,
    # windows 无控制台
    # console  有控制台
    windows=[{
        'script': 'main.py',
                'icon_resources': [(1, 'app.ico')],
    }],
    data_files=[
        ('', ['qt.conf']),

        # 注意PyQt5.5.1以下的版本没有/Qt 这个路径，需要删掉
        ('lib/plugins/platforms',
         glob.glob(qtpath + '/Qt/plugins/platforms/*.dll')),
        ('lib/plugins/iconengines',
         glob.glob(qtpath + '/Qt/plugins/iconengines/*.dll')),
        ('lib/plugins/imageformats',
         glob.glob(qtpath + '/Qt/plugins/imageformats/*.dll')),
        ('lib/plugins/printsupport',
         glob.glob(qtpath + '/Qt/plugins/printsupport/*.dll')),
    ]
)

# python setup.py py2exe
