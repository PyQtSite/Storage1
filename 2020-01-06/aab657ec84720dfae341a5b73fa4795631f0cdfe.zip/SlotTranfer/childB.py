# -*- coding: utf-8 -*-
"""
Created on Fri May 11 10:58:29 2018

@author: Administrator
"""

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget
from childBUI import Ui_W3

class W3(QWidget,Ui_W3):

    def __init__(self, parent=None):
        super(W3, self).__init__(parent)        
        self.setupUi(self)
