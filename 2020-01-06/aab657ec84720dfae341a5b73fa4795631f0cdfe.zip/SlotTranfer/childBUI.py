# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'childjiemian.ui'
#
# Created by: PyQt5 UI code generator 5.6
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets

class Ui_W3(object):
    def setupUi(self, W3):
        W3.setObjectName("W3")
        W3.resize(473, 409)
        self.label = QtWidgets.QLabel(W3)
        self.label.setGeometry(QtCore.QRect(60, 180, 121, 31))
        self.label.setObjectName("label")
        self.lineEdit = QtWidgets.QLineEdit(W3)
        self.lineEdit.setGeometry(QtCore.QRect(210, 180, 151, 31))
        self.lineEdit.setObjectName("lineEdit_3")

        font = QtGui.QFont()
        font.setFamily("楷体")
        font.setPointSize(24)
        font.setBold(True)
        font.setWeight(75)
        self.label_3 = QtWidgets.QLabel(W3)
        self.label_3.setFont(font)
        self.label_3.setObjectName("label_3")
        self.retranslateUi(W3)
        QtCore.QMetaObject.connectSlotsByName(W3)

    def retranslateUi(self, W3):
        _translate = QtCore.QCoreApplication.translate
        W3.setWindowTitle(_translate("W3", "Form"))
        self.label.setText(_translate("W3", "接收父窗体数据："))
        self.label_3.setText(_translate("W2", "子窗体B"))


   
        

