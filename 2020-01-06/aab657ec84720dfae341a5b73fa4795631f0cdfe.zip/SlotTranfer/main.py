# -*- coding: utf-8 -*-
"""
Created on Fri May 11 10:53:30 2018

@author: Administrator
"""

from PyQt5.QtCore import pyqtSignal
from PyQt5.QtWidgets import QWidget, QApplication
from mainUI import Ui_W1
from childA import W2
from childB import W3
class W1(QWidget, Ui_W1):
    parentclicked = pyqtSignal(str)   
    parentclicked2 = pyqtSignal(str)  
    def __init__(self, parent=None):
        super(W1, self).__init__(parent)        
        self.setupUi(self)
        self.w2 = W2() #子窗口A
        self.w3 = W3() #子窗口B
        self.pushButton.clicked.connect(self.childA)#打开子窗体A
        self.pushButton3.clicked.connect(self.childB)#打开子窗体B
        self.pushButton_2.clicked.connect(self.parentsend)
        self.parentclicked.connect(self.recv2)#  父窗体向子窗体A传数据的“信号与槽连接”
        self.parentclicked.connect(self.recv4)#  父窗体向子窗体B传数据的“信号与槽连接”
        self.parentclicked2.connect(self.recv3)  
        
    def childA(self):
        # self.w2 = W2()
        self.w2.childclicked.connect(self.recv)  #  字窗体向父窗体传数据的“信号与槽连接”
        self.w2.show()
        
    def childB(self):
        self.w3.show()

    # 父窗体向子窗体传数据
    def parentsend(self):
        parentstr = self.lineEdit_2.text()  # 父窗体输入的字符，发送给子窗体
        self.parentclicked.emit(parentstr)  #  父窗体向子窗体发射信号

    # 槽函数，子窗体A接收父窗体的数据
    def recv2(self, s):
        self.w2.lineEdit_2.setText(s)#子窗口A接收父窗口数据
        self.parentclicked2.emit(s) #信号二次发射
    # 槽函数，子窗体B接收父窗体的数据
    def recv4(self, s):
        self.w3.lineEdit.setText(s) #子窗口B接收父窗口数据
    
    def recv3(self, s):
        self.w2.lineEdit_3.setText(s)
    # 槽函数，父窗体接收子窗体的数据
    def recv(self, s):
        self.lineEdit.setText(s)

if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    ui = W1()
    ui.show()
    sys.exit(app.exec_())
